/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package bingogame;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * The BingoGame class gets two user inputs, one for the number of players  to 
 * play the game and two, the number of calls to be made before the game ends if
 * there is no winner. It then generates the number of bingo card for the 
 * players, then start to play the bingo game.
 * @Course and Section: COMP280-001
 * @author Imano Williams
 * @ID 950313157
 * @version 2.0, August 28, 2014
 */
public class BingoGame {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int numOfBingoPlayers=0;
        int callCounter=0;
        boolean input=false;
        
        //Continuously display to the user the amount of player that would be playing
        //and continue to display to the use if their input was not a number or
        // if they enter less than one or greater than 3.
        while(true||input){
            try{
                System.out.print("Enter number of players(1-3): ");
                //Scan in the 
                numOfBingoPlayers = in.nextInt();
                if(!(numOfBingoPlayers<1 ||numOfBingoPlayers>3)){
                    input=true;
                    break;
                } 
                System.out.println("Please follow directions!  "
                        + "Enter a single digit(1-3)!");
            }
            // Catch the user invalid input
            catch (InputMismatchException ime) {
                //skips over the invalid characters that are sitting input
                //stream
                in.skip(".*"); 
                System.out.println("Please follow directions!  "
                        + "Enter a single digit(1-3)!");
            }
        }
        //Continuously display to the user the amount of times they want the game to run for
        // before ending, if they enter less than 4 or greater than 75.
        while(true ||input){
            try{
                System.out.print("Enter how many calls you want "
                        + "\nto make(4-75) before the game ends without a "
                        + "winner: ");
                callCounter = in.nextInt();
                if(!(callCounter<4 ||callCounter>75)){
                    input=true;
                    break;
                }
                System.out.println("Please follow directions!  "
                        + "Enter an integer(4-75)!");
            }
            // Catch the user invalid input
            catch (InputMismatchException ime) {
                //skips over the invalid characters that are sitting input
                //stream
                in.skip(".*");
                System.out.println("Please follow directions! "
                    + " Enter an integet(4-75)!");
            }
        }
        
        BingoController bingoMaster = new BingoController(numOfBingoPlayers,
                callCounter);
        //Generates the bingo cards for the number of players
        bingoMaster.generateNumberofCards();
        //start to play the bingo game
        bingoMaster.playGame(); 
    }
    
}
