/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package bingogame;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

/**
 * The BingoController class deals with the generating the bingo cards and 
 * deciding on how the game should be played.
 * @Course and Section: COMP280-001
 * @author Imano Williams
 * @ID 950313157
 * @version 2.0, August 28, 2014
 */
public class BingoController {
     protected int numOfBingoPlayers;
    //create BingoCard array to store bingo cards
    private BingoCard [] bingoCard;
    private Random generator;  
    //Creat a list to store the bingo numbers to be called randomly
    private ArrayList<Integer> callNumberList;
    //Creat a list to store the number winners
    private ArrayList<Integer> winnerList;
    //Creat a list to store the bingo numbers that were called
    private ArrayList<String> numbersCalled;
    private int firstPrint = 0;
    //count the number of call made before a winner is found.
    private int callCounter;
    
    /**
     * Add numbers 1-75 to be randomly called.
     */
    private void addBingoNumbers(){
        for(int i=1;i<76;i++){
            callNumberList.add(i);
        }
    }
        
    /**
     *
     * @param numOfBingoPlayers
     */
    public BingoController(int numOfBingoPlayers, int callCounter){
        this.numOfBingoPlayers=numOfBingoPlayers;
        this.callCounter=callCounter;
        this.generator = new Random();
        this.callNumberList = new ArrayList<>();
        this.winnerList = new ArrayList<>();
        this.numbersCalled = new ArrayList<>();        
        this.bingoCard = new BingoCard[numOfBingoPlayers];          
    }
    
    /**
     * Generates the number of bingo cards to play the game based 
     * on the number players.
     */
    protected void generateNumberofCards(){
        for(int i = 0; i < numOfBingoPlayers; i++){
            bingoCard[i] = new BingoCard();
            bingoCard[i].generateBingoCard();
        }        
    }
    
    /**
     * Prints the number of bingo cards that will be playing the game.
     */
    private void printOutCards(){
        if(firstPrint==0){
            System.out.println("\nInitial Cards:");
        }
        else{
            System.out.println("\nFinal Cards:");
        }
        for(int i = 0;i<numOfBingoPlayers;i++){               
            bingoCard[i].toString(i);//prints out each of the player's card
        }
        firstPrint++;
    }
    
    /**
     * Check the players card for a winner. 
     * Generate a random bingo number, mark a card if generated number was
     * found. End games if there are winner(s).
     */
    private void checkForWinners(){
        //use to control the while loop to stop the game
        boolean endGame=true;
        //number to be marked on a bingo card
        int callNumber =0;
        //winner list counter
        int winList = 0;
        boolean winner=false;
        //number of bingo number calls that have been made
        int numOfCalls = 0;
        do{
            //generates a random number
            callNumber = generateCalls(callNumberList);
            numOfCalls++;
            for(int i = 0;i<numOfBingoPlayers;i++){
                //mark players bingo card with callNumber if it was found on card
                bingoCard[i].markCard(callNumber);
            }
            //Check for a winner win there are at least 4 calls made. Since, it 
            //requires a minimum of 4 calls for a winner to found.
            if(numOfCalls>=4){
                for(int i = 0;i<numOfBingoPlayers;i++){     
                    //check for a winning
                    winner = bingoCard[i].checkForWinningCard();
                    if(winner==true){
                        winnerList.add(i);//add player to winners list 
                        winList++;
                    }
                }
                //end the game if there are winner(s)
                if(winList>0){
                    endGame = false;
                }
                //end the game if no winner and number of calls is 
                if(winList==0 && numOfCalls>callCounter){
                    endGame = false;
                }
            }                      
        }
        while(endGame);
    }
    
    /**
     * Checks winners list and print number of winning player.
     */
    private void printWinners(){
        if(winnerList.isEmpty()){
            System.out.println("Winner: No winner:");
        }
        else{
            for (Integer winnerList1 : winnerList) {
                System.out.println("\nWinner: Player " + winnerList1);
            }
        }
    }
    /**
     * Randomly generates the calling number
     * @param someArrayList
     * @return the calling number to be marked on a bingo card
     */
    private int generateCalls(ArrayList<Integer> someArrayList){
        //randomize the numbers in the list
        Collections.shuffle(someArrayList);
        //randomly pick an index to get a number from
        int index = generator.nextInt(someArrayList.size());
        int bingoNumber = someArrayList.get(index);
        
        //checks which column the ramdomly picked bingo number belongs to.
        char bingoColumn;
        if(bingoNumber<=15)
            bingoColumn = 'B';
        else if (bingoNumber<=30)
            bingoColumn = 'I';
        else if (bingoNumber<=45)
            bingoColumn = 'N';
        else if (bingoNumber<=60)
            bingoColumn = 'G';
        else 
            bingoColumn = 'O';
        
        //adds the bingo column letter to the bingo number
        switch(bingoColumn) {
            case 'B':
                numbersCalled.add("B"+bingoNumber);                                     
                break;  
            case 'I':
                numbersCalled.add("I"+bingoNumber);
                break;
	    case 'N':
                numbersCalled.add("N"+bingoNumber);
                    break;
            case 'G':
                numbersCalled.add("G"+bingoNumber);
                    break;
            case 'O':
                numbersCalled.add("O"+bingoNumber);
                    break;  
        }
        //remove the number that was called. I chose to use this way to not 
        //repeat numbers and using a while loop would make the porgram take long
        someArrayList.remove(index);
        return bingoNumber;
        
    }
    
    /**
     * Play the game by generating the cards, printing out the cards, check for 
     * winners, print out calling numbers for the game, print out final cards 
     * and then print out the winner(s).
     * 
     */
    protected void playGame(){
        //Genrates the number of bingo cards for the game.
        this.generateNumberofCards();
        //Prints out the initial bingo cards.
        this.printOutCards();
        //Create bingo calling numbers
        this.addBingoNumbers();
        //Checks for the winner or not
        this.checkForWinners();
        //Prints out the numbers that were called during he game
        this.printOutCalls();
        //Prints out the final bingo cards.
        this.printOutCards();
        //Prints out the players that won
        this.printWinners();  
        
    }
    
    /**
     * Prints each of the bingo numbers that were called in the game.
     */
    private void printOutCalls(){
       System.out.print("\nCalls: "); 
       for(int i=1; i<numbersCalled.size();i++){
           
           System.out.print(numbersCalled.get(i));
           if(i<numbersCalled.size()-1){
           System.out.print(",");
           }
       } 
    }
}
