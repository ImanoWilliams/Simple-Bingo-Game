/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package bingogame;

import java.util.Random;

/**
 * The Bingo Card class represent a Bingo Card Objects.
 * @Course and Section: COMP280-001
 * @author Imano Williams
 * @ID 950313157
 * @version 2.0, August 28, 2014
 */

public class BingoCard{

    private static final int ROWS=5;//Number of rows for Bingo Card
    private static final int COLS=5;//Number of columns for Bingo Cards
    public int[][] bCard;//Two Dimensional Array Bingo Card
    Random generator;
    
    
    /**
     * Class constructor
     */	
    public BingoCard(){
        this.generator = new Random();
        bCard = new int[ROWS][COLS];
    }
    
    /**
     * Populates a Bingo Card with numbers for each column
     */	
    protected void generateBingoCard(){
        //populates the "B" column in a Bingo Card
        generateColumnNumbers(0,1); 
        //populates the "I" column in a Bingo Card
        generateColumnNumbers(1,16);  
        //populates the "N" column in a Bingo Card
        generateColumnNumbers(2,31); 
        //populates the "G" column in a Bingo Card
        generateColumnNumbers(3,46); 
        //populates the "O" column in a Bingo Card
        generateColumnNumbers(4,61); 
    }
    
    /**
     * Prints a Bingo Card 
     * @param playerNumber is use to display which player card it is.
     */           
    protected void toString(int playerNumber){
	System.out.println("\n\tPlayer "+playerNumber+":");
	System.out.println("\tB    \tI    \tN    \tG    \tO");
	for (int[] bCard1 : bCard) {
            for (int j = 0; j<bCard[0].length; j++) {
                //Prints a number
                System.out.print("\t" + bCard1[j]);
            }
            System.out.print("\n");
        }
    }
    
    /**
     * Mark a number that was randomly generated.  
     * @param callingNumber in the number that is search for on a bingo card.
     * When the callingnumber is found on the bingo card, that number is replace
     * zero.
     */    
    protected void markCard (int callingNumber){
        char bingoColumn;
        if(callingNumber<=15)
            bingoColumn = 'B';
        else if (callingNumber<=30)
            bingoColumn = 'I';
        else if (callingNumber<=45)
            bingoColumn = 'N';
        else if (callingNumber<=60)
            bingoColumn = 'G';
        else 
            bingoColumn = 'O';
        
        /*Checks the column that the calling number belongs to and set the 
          number to zero if it was found.*
        */
        switch(bingoColumn) {
            case 'B':
                for (int[] bCard1 : bCard) {
                    if (callingNumber == bCard1[0]) {
                        //Assign zero to index that equals to calling number
                        bCard1[0] = 0;
                    }
                }
                break;				
            case 'I':
                for (int[] bCard1 : bCard) {
                    if (callingNumber == bCard1[1]) {
                        //Assign zero to index that equals to calling number
                        bCard1[1] = 0;
                    }
                }
                break;
	    case 'N':
                for (int[] bCard1 : bCard) {
                    if (callingNumber == bCard1[2]) {
                        //Assign zero to index that equals to calling number
                        bCard1[2] = 0;
                    }
                }
                break;
            case 'G':
                for (int[] bCard1 : bCard) {
                    if (callingNumber == bCard1[3]) {
                        //Assign zero to index that equals to calling number
                        bCard1[3] = 0;
                    }
                }
                break;
            case 'O':
                for (int[] bCard1 : bCard) {
                    if (callingNumber == bCard1[4]) {
                        //Assign zero to index that equals to calling number
                        bCard1[4] = 0;
                    }
                }
                break;    
        }
    }
    
    /**
     * Checks for a winning card
     * @return true if there is a winning pattern on a bingo card
     */    
    protected boolean checkForWinningCard(){
        boolean playerWin = false;
        //looks for a winning pattern in the column
        int columnSum;
        for (int i = 0;  i < COLS;  i++){
            columnSum=0;//variable to store sum of a column             
            for (int j = 0;  j < ROWS;  j++){
                columnSum += this.bCard[j][i];
            }
            if (columnSum == 0){
                playerWin = true;
            }
        }
        //looks for a winning pattern in the row
        int rowSum;
        for (int i = 0;  i < ROWS;  i++){
            rowSum=0;//variable to store sum of a row
            for (int j = 0;  j < COLS;  j++){
                rowSum += this.bCard[i][j];
            }
            if (rowSum == 0){
                playerWin = true;
            }
        }
        
        //looks for a winning pattern in the main diagonal
        int sumMainDiagonal =0;//variable to store sum of a main diagonal
        for (int i = 0; i < bCard.length; i++) {
            sumMainDiagonal += bCard[i][i];
        }
        if(sumMainDiagonal==0){
            playerWin = true;
        }
        
        //look for a winning patter in the anti-diagonal
        int sumAntiDiagonal =0;//variable to store sum of a anti diagonal
        int j = COLS - 1;
        for (int i = 0; i < COLS; i++) {
            if (j >= 0) {
                sumAntiDiagonal += bCard[i][j];
                    j--;
            }
        }
        if(sumAntiDiagonal == 0){
            playerWin = true;
        }
        return playerWin;
    }
            
    /**
     * Check if the number to be added into a specific column in the Bingo Card
     * is duplicate of an existing number already in that column.
     * @param colNumber specific column to check
     * @param input value of the number to be added to the column
     * @return boolean value, duplicate. If the input is a duplicate the return 
     * is true else false.
     */
    private boolean isADuplicate(int colNumber, int input){
        boolean duplicate = false;
        for(int i = 0; i<COLS;i++){
            if(bCard[i][colNumber]== input){
                duplicate = true;
                break;// Breaks out of the for loop once the condition is true.
            }
        }
        return duplicate;
    }
    
    /**
     * Populates a selected column on the Bingo Card
     * @param columnNumber is the column to be populated.
     * @param randMin is minimum number that can be added into a column 
     */
    private void generateColumnNumbers(int columnNumber, int randMin){
        boolean duplicate=true;
        int bNumber=0;         
        for(int i=0; i<COLS;i++){                    
            do{
                //generates a bingo number between randMin and 15+randMin
                //inclusively.
                bNumber = generator.nextInt(15) + randMin;
                duplicate = isADuplicate(columnNumber,bNumber);
            }
            while(duplicate);//continue to random generate a number if true
            if(i==2 && columnNumber ==2){
                //assign 0 to the center of the bingo card
                bCard[i][columnNumber] = 0;
            }
            else{
                //assign bnumber to 2D Array index
                bCard[i][columnNumber] = bNumber;
            }                     
        }
    }
}
